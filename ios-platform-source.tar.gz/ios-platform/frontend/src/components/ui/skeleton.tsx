"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {}

const Skeleton = React.forwardRef<HTMLDivElement, SkeletonProps>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("shimmer rounded-md bg-muted", className)} {...props} />
));
Skeleton.displayName = "Skeleton";

export { Skeleton };
